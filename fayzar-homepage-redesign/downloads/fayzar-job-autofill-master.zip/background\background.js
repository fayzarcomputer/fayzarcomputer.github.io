/**
 * Fayzar Job AutoFill Master Edition - Service Worker v3.0
 */

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: 'fayzar_master_root',
    title: '⚡ ফয়জার মাস্টার অটো-ফিল (Shop Edition)',
    contexts: ['page', 'editable']
  });

  chrome.contextMenus.create({
    id: 'fayzar_master_autofill',
    parentId: 'fayzar_master_root',
    title: '✨ নির্বাচিত প্রার্থীর তথ্যে ১-ক্লিকে পূরণ করুন',
    contexts: ['page', 'editable']
  });

  chrome.contextMenus.create({
    id: 'fayzar_master_capture',
    parentId: 'fayzar_master_root',
    title: '💾 গ্রাহকের ফর্মটি ক্লাউডে নতুন প্রার্থী হিসেবে সেভ করুন',
    contexts: ['page', 'editable']
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (!tab || !tab.id) return;

  if (info.menuItemId === 'fayzar_master_autofill') {
    chrome.storage.local.get(['fayzar_master_active_candidate'], (res) => {
      const targetCandidate = res.fayzar_master_active_candidate;
      if (!targetCandidate) {
        return;
      }
      chrome.tabs.sendMessage(tab.id, {
        action: 'AUTOFILL_FORM',
        profileData: targetCandidate
      }, () => {
        if (chrome.runtime.lastError) {}
      });
    });
  }

  if (info.menuItemId === 'fayzar_master_capture') {
    chrome.tabs.sendMessage(tab.id, { action: 'CAPTURE_FORM' }, (response) => {
      if (chrome.runtime.lastError || !response) return;

      const profileName = (tab.title || 'অনলাইন আবেদন') + ' - ' + new Date().toLocaleDateString('bn-BD');
      const newCand = {
        id: 'cand_' + Date.now(),
        name: profileName,
        updatedAt: new Date().toISOString(),
        semanticMap: response.semanticMap,
        fields: response.fields
      };

      chrome.storage.local.set({ fayzar_master_active_candidate: newCand });
    });
  }
});
