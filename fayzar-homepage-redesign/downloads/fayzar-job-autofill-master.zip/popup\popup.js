/**
 * Fayzar Job AutoFill Master Edition - Popup Script v3.0
 * 100% Online Cloud Sync & Global Candidate Management
 */

(function () {
  'use strict';

  // DOM Elements
  const authScreen = document.getElementById('authScreen');
  const mainScreen = document.getElementById('mainScreen');
  const adminPinForm = document.getElementById('adminPinForm');
  const adminPinInput = document.getElementById('adminPinInput');
  const authErrorMsg = document.getElementById('authErrorMsg');
  const logoutBtn = document.getElementById('logoutBtn');
  const cloudStatusBadge = document.getElementById('cloudStatusBadge');

  const candidateSearchInput = document.getElementById('candidateSearchInput');
  const refreshCloudBtn = document.getElementById('refreshCloudBtn');
  const searchResultsDropdown = document.getElementById('searchResultsDropdown');

  const selectedCandidateCard = document.getElementById('selectedCandidateCard');
  const candPhotoImg = document.getElementById('candPhotoImg');
  const candNameDisplay = document.getElementById('candNameDisplay');
  const candMobileDisplay = document.getElementById('candMobileDisplay');
  const candNidDisplay = document.getElementById('candNidDisplay');
  const candFatherDisplay = document.getElementById('candFatherDisplay');
  const candDobDisplay = document.getElementById('candDobDisplay');

  const autofillCurrentTabBtn = document.getElementById('autofillCurrentTabBtn');
  const captureCurrentTabBtn = document.getElementById('captureCurrentTabBtn');
  const openAdminPanelBtn = document.getElementById('openAdminPanelBtn');
  const actionStatusMsg = document.getElementById('actionStatusMsg');

  const candidateCountBadge = document.getElementById('candidateCountBadge');
  const recentCandidatesList = document.getElementById('recentCandidatesList');

  // State
  let allMasterCandidates = [];
  let currentActiveCandidate = null;

  // Initialize
  init();

  async function init() {
    // Check if master session already authenticated
    chrome.storage.local.get(['fayzar_master_auth', 'fayzar_master_active_candidate'], async (res) => {
      if (res.fayzar_master_auth && res.fayzar_master_auth.isLoggedIn) {
        showDashboard();
        if (res.fayzar_master_active_candidate) {
          selectCandidate(res.fayzar_master_active_candidate);
        }
        await loadAllCloudCandidates();
      } else {
        showAuth();
      }
    });

    bindEvents();
  }

  function bindEvents() {
    // 1. PIN Submit
    adminPinForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const pin = adminPinInput.value.trim();
      if (!pin) return;

      authErrorMsg.style.display = 'none';
      const verifyRes = await FayzarFirebaseClient.verifyAdminPin(pin);

      if (verifyRes.success) {
        chrome.storage.local.set({
          fayzar_master_auth: {
            isLoggedIn: true,
            loginTime: new Date().toISOString()
          }
        }, () => {
          showDashboard();
          loadAllCloudCandidates();
        });
      } else {
        authErrorMsg.textContent = verifyRes.error || 'ভুল পিন নম্বর!';
        authErrorMsg.style.display = 'block';
      }
    });

    // 2. Logout
    logoutBtn.addEventListener('click', () => {
      chrome.storage.local.remove(['fayzar_master_auth'], () => {
        showAuth();
      });
    });

    // 3. Search Input
    candidateSearchInput.addEventListener('input', () => {
      const q = candidateSearchInput.value.trim().toLowerCase();
      renderSearchResults(q);
    });

    // Close dropdown on outside click
    document.addEventListener('click', (e) => {
      if (!candidateSearchInput.contains(e.target) && !searchResultsDropdown.contains(e.target)) {
        searchResultsDropdown.style.display = 'none';
      }
    });

    // 4. Refresh Cloud Data
    refreshCloudBtn.addEventListener('click', async () => {
      refreshCloudBtn.textContent = '⏳';
      await loadAllCloudCandidates();
      refreshCloudBtn.textContent = '🔄';
      showStatus('ক্লাউড ডেটাবেজ সফলভাবে রিফ্রেশ হয়েছে!', 'success');
    });

    // 5. 1-Click AutoFill on Active Tab
    autofillCurrentTabBtn.addEventListener('click', async () => {
      if (!currentActiveCandidate) {
        showStatus('অনুগ্রহ করে প্রথমে একজন প্রার্থী নির্বাচন করুন!', 'error');
        return;
      }

      autofillCurrentTabBtn.textContent = '⏳ তথ্য পূরণ হচ্ছে...';
      autofillCurrentTabBtn.disabled = true;

      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab || !tab.id) {
        showStatus('সক্রিয় ওয়েব ট্যাব পাওয়া যায়নি!', 'error');
        autofillCurrentTabBtn.textContent = '⚡ ১-ক্লিকে বর্তমান ফর্ম পূরণ করুন';
        autofillCurrentTabBtn.disabled = false;
        return;
      }

      chrome.tabs.sendMessage(tab.id, {
        action: 'AUTOFILL_FORM',
        profileData: currentActiveCandidate
      }, (response) => {
        autofillCurrentTabBtn.textContent = '⚡ ১-ক্লিকে বর্তমান ফর্ম পূরণ করুন';
        autofillCurrentTabBtn.disabled = false;

        if (chrome.runtime.lastError) {
          showStatus('ফর্ম পেজে স্ক্রিপ্ট সংযুক্ত করা যায়নি। পেজটি একবার রিলোড করুন।', 'error');
          return;
        }

        if (response && response.success) {
          showStatus(`✅ সফল! ${response.filledCount || 0} টি ঘর পূরণ করা হয়েছে।`, 'success');
        } else {
          showStatus('ফর্ম পূরণ সম্পন্ন হয়েছে। কিছু ঘর ম্যানুয়ালি যাচাই করুন।', 'success');
        }
      });
    });

    // 6. Capture Form on Active Tab to Cloud
    captureCurrentTabBtn.addEventListener('click', async () => {
      captureCurrentTabBtn.textContent = '⏳ ক্যাপচার হচ্ছে...';
      captureCurrentTabBtn.disabled = true;

      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab || !tab.id) {
        showStatus('সক্রিয় ওয়েব ট্যাব পাওয়া যায়নি!', 'error');
        captureCurrentTabBtn.textContent = '💾 ফর্ম ডেটা ক্লাউডে সেভ করুন';
        captureCurrentTabBtn.disabled = false;
        return;
      }

      chrome.tabs.sendMessage(tab.id, { action: 'CAPTURE_FORM' }, async (response) => {
        captureCurrentTabBtn.textContent = '💾 ফর্ম ডেটা ক্লাউডে সেভ করুন';
        captureCurrentTabBtn.disabled = false;

        if (chrome.runtime.lastError || !response) {
          showStatus('ফর্ম ডেটা ক্যাপচার করা যায়নি। পেজে কোনো ফর্ম আছে কি না নিশ্চিত করুন।', 'error');
          return;
        }

        const candidateName = response.semanticMap?.applicant_name_bn || response.semanticMap?.applicant_name || 'নতুন প্রার্থী';
        const mobile = response.semanticMap?.mobile_no || '';

        const newCand = {
          id: 'cand_' + Date.now(),
          name: candidateName,
          mobile: mobile,
          updatedAt: new Date().toISOString(),
          semanticMap: response.semanticMap || {},
          fields: response.fields || []
        };

        // Save to Firestore Cloud
        const saveRes = await FayzarFirebaseClient.saveGlobalCandidate(newCand);
        if (saveRes.success) {
          showStatus(`✅ প্রার্থীর তথ্য ক্লাউডে সংরক্ষিত হয়েছে: ${candidateName}`, 'success');
          selectCandidate(newCand);
          loadAllCloudCandidates();
        } else {
          showStatus('ক্লাউডে সেভ করতে সমস্যা হয়েছে: ' + (saveRes.error || ''), 'error');
        }
      });
    });

    // 7. Open Admin Panel
    openAdminPanelBtn.addEventListener('click', () => {
      chrome.tabs.create({ url: 'https://fayzarcomputer.github.io/admin.html' });
    });
  }

  // Load All Master Candidates from Firestore
  async function loadAllCloudCandidates() {
    cloudStatusBadge.textContent = '⏳ লোড হচ্ছে';
    try {
      const res = await FayzarFirebaseClient.fetchAllMasterCandidates();
      if (res.success && res.candidates) {
        allMasterCandidates = res.candidates;
        candidateCountBadge.textContent = `${allMasterCandidates.length} জন`;
        cloudStatusBadge.textContent = '🟢 লাইভ';
        renderRecentList();
      } else {
        cloudStatusBadge.textContent = '⚠️ ত্রুটি';
      }
    } catch (e) {
      cloudStatusBadge.textContent = '⚠️ অফলাইন';
    }
  }

  // Render Search Results
  function renderSearchResults(q) {
    if (!q || q.length < 1) {
      searchResultsDropdown.style.display = 'none';
      return;
    }

    const matches = allMasterCandidates.filter(c => {
      const name = (c.name || c.semanticMap?.applicant_name || '').toLowerCase();
      const nameBn = (c.semanticMap?.applicant_name_bn || '').toLowerCase();
      const mobile = (c.mobile || c.userMobile || c.semanticMap?.mobile_no || '').toLowerCase();
      const nid = (c.semanticMap?.nid_no || '').toLowerCase();
      return name.includes(q) || nameBn.includes(q) || mobile.includes(q) || nid.includes(q);
    });

    if (matches.length === 0) {
      searchResultsDropdown.innerHTML = '<div class="search-item" style="color:var(--text-muted);text-align:center;">কোনো প্রার্থী পাওয়া যায়নি</div>';
      searchResultsDropdown.style.display = 'block';
      return;
    }

    searchResultsDropdown.innerHTML = matches.slice(0, 10).map(c => {
      const name = c.name || c.semanticMap?.applicant_name_bn || c.semanticMap?.applicant_name || 'নামবিহীন প্রার্থী';
      const mobile = c.mobile || c.userMobile || c.semanticMap?.mobile_no || 'মোবাইল নেই';
      const nid = c.semanticMap?.nid_no || '';
      return `
        <div class="search-item" data-id="${c.id}">
          <div>
            <div class="search-item-title">${escapeHtml(name)}</div>
            <div class="search-item-sub">📱 ${escapeHtml(mobile)} ${nid ? `&bull; NID: ${escapeHtml(nid)}` : ''}</div>
          </div>
          <span class="select-arrow">👉</span>
        </div>
      `;
    }).join('');

    searchResultsDropdown.style.display = 'block';

    // Item click
    searchResultsDropdown.querySelectorAll('.search-item').forEach(item => {
      item.addEventListener('click', () => {
        const id = item.getAttribute('data-id');
        const cand = allMasterCandidates.find(c => c.id === id);
        if (cand) {
          selectCandidate(cand);
          searchResultsDropdown.style.display = 'none';
          candidateSearchInput.value = '';
        }
      });
    });
  }

  // Select Candidate
  function selectCandidate(cand) {
    currentActiveCandidate = cand;
    chrome.storage.local.set({ fayzar_master_active_candidate: cand });

    const sMap = cand.semanticMap || {};
    const name = cand.name || sMap.applicant_name_bn || sMap.applicant_name || 'প্রার্থী';
    const mobile = cand.mobile || cand.userMobile || sMap.mobile_no || '-';
    const nid = sMap.nid_no || '-';
    const father = sMap.father_name_bn || sMap.father_name || '-';
    const dob = sMap.dob_full || (sMap.dob_day ? `${sMap.dob_day}/${sMap.dob_month}/${sMap.dob_year}` : '-');

    candNameDisplay.textContent = name;
    candMobileDisplay.textContent = `📱 মোবাইল: ${mobile}`;
    candNidDisplay.textContent = `🆔 NID: ${nid}`;
    candFatherDisplay.textContent = `পিতা: ${father}`;
    candDobDisplay.textContent = `জন্ম: ${dob}`;

    // Set photo if present
    if (sMap.photo_base64 || cand.photoBase64) {
      candPhotoImg.src = sMap.photo_base64 || cand.photoBase64;
    } else {
      candPhotoImg.src = '../icons/icon48.png';
    }

    selectedCandidateCard.classList.add('active');
    autofillCurrentTabBtn.disabled = false;
  }

  // Render Recent Candidates List
  function renderRecentList() {
    if (allMasterCandidates.length === 0) {
      recentCandidatesList.innerHTML = '<div class="loading-spinner">কোনো প্রার্থী সংরক্ষিত নেই।</div>';
      return;
    }

    recentCandidatesList.innerHTML = allMasterCandidates.slice(0, 5).map(c => {
      const name = c.name || c.semanticMap?.applicant_name_bn || c.semanticMap?.applicant_name || 'নামবিহীন';
      const mobile = c.mobile || c.userMobile || c.semanticMap?.mobile_no || '-';
      return `
        <div class="recent-item" data-id="${c.id}">
          <div class="recent-item-info">
            <span class="recent-name">${escapeHtml(name)}</span>
            <span class="recent-sub">📱 ${escapeHtml(mobile)}</span>
          </div>
          <span class="select-arrow">👉</span>
        </div>
      `;
    }).join('');

    recentCandidatesList.querySelectorAll('.recent-item').forEach(item => {
      item.addEventListener('click', () => {
        const id = item.getAttribute('data-id');
        const cand = allMasterCandidates.find(c => c.id === id);
        if (cand) selectCandidate(cand);
      });
    });
  }

  // UI Helpers
  function showAuth() {
    authScreen.style.display = 'block';
    mainScreen.style.display = 'none';
    logoutBtn.style.display = 'none';
    adminPinInput.value = '';
  }

  function showDashboard() {
    authScreen.style.display = 'none';
    mainScreen.style.display = 'block';
    logoutBtn.style.display = 'inline-block';
  }

  function showStatus(msg, type = 'success') {
    actionStatusMsg.textContent = msg;
    actionStatusMsg.className = `status-toast ${type}`;
    actionStatusMsg.style.display = 'block';
    setTimeout(() => {
      actionStatusMsg.style.display = 'none';
    }, 4000);
  }

  function escapeHtml(str) {
    return (str || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }
})();
