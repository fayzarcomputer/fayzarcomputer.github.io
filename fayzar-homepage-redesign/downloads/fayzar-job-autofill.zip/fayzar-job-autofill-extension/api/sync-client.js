/**
 * Fayzar Job AutoFill - Multi-PC Cloud Sync Client
 * Supports Local Shop Server (/api/candidates) & Online GitHub Cloud Fallback
 */

const FayzarSyncClient = {
  defaultLocalUrl: 'http://localhost:3000/api/candidates',
  defaultCloudUrl: 'https://raw.githubusercontent.com/fayzarcomputer/fayzarcomputer.github.io/main/data/candidates.json',

  // Fetch candidate profiles from local server or cloud
  async fetchProfiles(customUrl = null) {
    let targetUrl = customUrl || this.defaultLocalUrl;

    // 1. Try local or custom server
    try {
      const response = await fetch(targetUrl, {
        method: 'GET',
        headers: { 'Accept': 'application/json' },
        signal: AbortSignal.timeout(3000)
      });

      if (response.ok) {
        const data = await response.json();
        const profiles = Array.isArray(data) ? data : (data.profiles || []);
        return { success: true, source: 'local_server', profiles };
      }
    } catch (err) {
      console.log('Local server unavailable, attempting cloud sync fallback...');
    }

    // 2. Cloud Fallback (GitHub Raw repository)
    try {
      const cloudRes = await fetch(this.defaultCloudUrl, {
        method: 'GET',
        headers: { 'Accept': 'application/json' },
        signal: AbortSignal.timeout(4000)
      });

      if (cloudRes.ok) {
        const data = await cloudRes.json();
        const profiles = Array.isArray(data) ? data : (data.profiles || []);
        return { success: true, source: 'github_cloud', profiles };
      }
    } catch (cloudErr) {
      console.warn('Cloud sync error:', cloudErr);
    }

    return { success: false, error: 'সার্ভার বা ক্লাউড সংযোগ পাওয়া যায়নি।' };
  },

  // Upload profiles to the server
  async uploadProfiles(profiles, customUrl = null) {
    const targetUrl = customUrl || this.defaultLocalUrl;
    try {
      const response = await fetch(targetUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Client-App': 'FayzarJobAutoFill-Extension'
        },
        body: JSON.stringify(profiles),
        signal: AbortSignal.timeout(4000)
      });

      if (response.ok) {
        const resData = await response.json();
        return { success: true, count: profiles.length, resData };
      }
    } catch (err) {
      console.warn('Upload error:', err);
    }
    return { success: false, error: 'সার্ভারে ডাটা পাঠানো যায়নি।' };
  },

  // Smart 2-way Merge: combines local and remote profiles without losing data
  mergeProfiles(localProfiles = [], remoteProfiles = []) {
    const map = new Map();

    // 1. Add all local profiles
    localProfiles.forEach(p => {
      if (p && p.id) map.set(p.id, p);
    });

    // 2. Merge remote profiles, updating if newer
    remoteProfiles.forEach(rp => {
      if (!rp || !rp.id) return;
      if (!map.has(rp.id)) {
        map.set(rp.id, rp);
      } else {
        const lp = map.get(rp.id);
        const lTime = new Date(lp.updatedAt || 0).getTime();
        const rTime = new Date(rp.updatedAt || 0).getTime();
        if (rTime > lTime) {
          map.set(rp.id, rp);
        }
      }
    });

    return Array.from(map.values());
  }
};

if (typeof module !== 'undefined' && module.exports) {
  module.exports = FayzarSyncClient;
}
